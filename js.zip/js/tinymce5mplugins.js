/* ****************************************************************************************************** *
 *
 *  5M-Ware Web Solution License
 *  Copyright 2014, 5M-Ware
 *
 *  info@5m-ware.eu
 *
 *  Javascript part of the 'tinyMCE 5M-Ware Plugin Extensions'
 *  Version 1.1
 *  Stable
 *
 *  Description:
 *  Contents several functions to create plugins into the tinymce-editing instances.
 *
 *  Dependencies:
 *  tinymce ver. >= 4
 *  wepi_core.js
 *  wepi_serv.js
 *  tinymce5mext.php
 *
 *  Plugins:
 *  plugin_block.php
 *  plugin_table01.php
 *  plugin_pagelink.php
 *  plugin_uploadsifi.php
 *
 * ****************************************************************************************************** */


/* ****************************************************************************************************** *
 * ****************************************************************************************************** *
 * reformation function
 * ****************************************************************************************************** *
 * ****************************************************************************************************** */

function re_format( value ) {
	var i = 0; var container = "";
	// *** //
	for ( i = 0; i < value.length; i++ ) {
		if ( value.charCodeAt(i) <= 127 ) {
			if ( value.charAt(i) == ' ' ) {
				container += "&nbsp;";
			} else if ( value.charAt(i) == "\t" ) {
				container += "&nbsp;&nbsp;&nbsp;";
			} else {
				container += value.charAt(i);
			}
		} else {
			container += "&#" + value.charCodeAt(i) + ";";
		}
	}
	// *** //
	return container;
}

tinymce.PluginManager.add( 'tinymce5mWare_PlugIns', function( editor, url ) {

    /* ****************************************************************************************************** *
	 * ****************************************************************************************************** *
	 * eBay Button
	 * ****************************************************************************************************** *
	 * ****************************************************************************************************** */
    editor.addButton('btn5meBayCode', {
        text: 'eBay',
        icon: false,
		tooltip: 'eBay Code generieren',
        onclick: function() {
			editor.windowManager.open({
				title: "eBay Code Generator",
				url: 'plugin_ebay.php',
				width: 700,
				height: 480
			}, {
				arg1: tinyMCE.activeEditor.getContent({format : 'raw'})
			});
        }
    });

    /* ****************************************************************************************************** *
	 * ****************************************************************************************************** *
	 * Block
	 * ****************************************************************************************************** *
	 * ****************************************************************************************************** */
    editor.addButton('btn5mBlock', {
        text: 'Block',
        icon: false,
		tooltip: 'Block',
        onclick: function() {
            // Open window with a specific url
            editor.windowManager.open({
                title: 'Block',
                url: 'plugin_block.php?<?php echo session_id(); ?>',
                width: 560,
                height: 420,
                buttons: [{
                    text: 'Close',
                    onclick: 'close'},{
                    text: 'Paste',
                    onclick: function(e) {
						var mart = trim(svr.Sess('tinymce_plugin_margin_top'));
						var marl = trim(svr.Sess('tinymce_plugin_margin_lft'));
						var marr = trim(svr.Sess('tinymce_plugin_margin_rgt'));
						var marb = trim(svr.Sess('tinymce_plugin_margin_bot'));
						// *** //
						var padt = trim(svr.Sess('tinymce_plugin_padding_top'));
						var padl = trim(svr.Sess('tinymce_plugin_padding_lft'));
						var padr = trim(svr.Sess('tinymce_plugin_padding_rgt'));
						var padb = trim(svr.Sess('tinymce_plugin_padding_bot'));
						// *** //
						var code = "";
						// *** //
						code  = '<table border = "0" cellspacing = "0" cellpadding = "0"><tr><td valign = "top" align = "center" style = "' +
								'padding-top:' + mart + 'px;' +
								'padding-left:' + marl + 'px;' +
								'padding-right:' + marr + 'px;' +
								'padding-bottom:' + marb + 'px;' +
								'">' +
								'<table border = "0" cellspacing = "0" cellpadding = "0" width = "100%"><tr><td valign = "top" width = "100%" style = "' +
								'padding-top:' + padt + 'px;' +
								'padding-left:' + padl + 'px;' +
								'padding-right:' + padr + 'px;' +
								'padding-bottom:' + padb + 'px;' +
								'">' +
								'<br /><br /><br /><br /><br />' +
								'</td></tr></table>' +
								'</td></tr></table>';
						// *** //
						if ( code != "" ) { tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, code ); }
						// *** //
						editor.windowManager.close();
					}
                }]
            });
        }
    });

    /* ****************************************************************************************************** *
	 * ****************************************************************************************************** *
	 * Preview Button
	 * ****************************************************************************************************** *
	 * ****************************************************************************************************** */
    editor.addButton('btn5mPreview', {
        text: 'Vorschau',
        icon: false,
		tooltip: 'Vorschau',
        onclick: function() {
			var src = trim(svr.Sess("tinymce_preview_current_edit_src"));
			// *** //
			src = src.replace(/&amp;/g,'&');
			// *** //
			window.open( src, "_blank" );
			//tinyMCE.activeEditor.execCommand('mcePreview');
        }
    });

    /* ****************************************************************************************************** *
	 * ****************************************************************************************************** *
	 * Button Page-Linker
	 * ****************************************************************************************************** *
	 * ****************************************************************************************************** */
    editor.addButton('btn5mPage', {
        text: 'Einbetten',
        icon: false,
		tooltip: 'Inhalt einbetten',
        onclick: function() {
            // Open window with a specific url
            editor.windowManager.open({
                title: 'Inhalt einbetten',
				url: 'plugin_button_pagelink.php?<?php echo session_id(); ?>&lang=<?php echo $lang; ?>',
                width: 400,
                height: 300,
                buttons: [{
                    text: 'Close',
                    onclick: 'close'},{
                    text: 'Paste',
                    onclick: function(e) {
						var src = trim(svr.Sess("tinymce_plugin_src"));
						var idn = trim(svr.Sess("tinymce_plugin_id"));
						var txt = trim(svr.Sess("tinymce_plugin_text"));
						// *** //
						tinyMCE.activeEditor.execCommand(
							'mceInsertContent', 
							false, '<a href = "index.php?page=conn&mode=' + idn + '">' + txt + '</a>'
						);
						// *** //
						editor.windowManager.close();
					}
                }]
            });
        }
    });

    /* ****************************************************************************************************** *
	 * ****************************************************************************************************** *
	 * Bilder mit automatischer Reihenfolge und Klickbar mit Effekt und Full-Size-View
	 * ****************************************************************************************************** *
	 * ****************************************************************************************************** */
    editor.addButton('btn5mL', {
        text: 'Effektvolle Bilder',
        icon: false,
		tooltip: 'Effektvolle Bilder einbetten',
        onclick: function() {
            // Open window with a specific url
            editor.windowManager.open({
                title: 'Effektvolle Bilder einbetten',
				url: 'plugin_button_effect_pics.php?<?php echo session_id(); ?>&lang=<?php echo $lang; ?>',
                width: 400,
                height: 300,
                buttons: [{
                    text: 'Close',
                    onclick: 'close'},{
                    text: 'Paste',
                    onclick: function(e) {
						var src = trim(svr.Sess("tinymce_plugin_src"));
						var idn = trim(svr.Sess("tinymce_plugin_id"));
						var txt = trim(svr.Sess("tinymce_plugin_text"));
						// *** //
						var con = '<ul class = "floater">';
						// *** //
						var pos = 0;
						// *** //
						for ( pos = 0; pos < parseInt(idn); pos++ ) {
							con += '<li class = "pickerItem">Bild' + (pos + 1) + '</li>';
						}
						// *** //
						con += "</ul>";
						// *** //
						tinyMCE.activeEditor.execCommand(
							'mceInsertContent', 
							false, con
						);
						// *** //
						editor.windowManager.close();
					}
                }]
            });
        }
    });

    /* ****************************************************************************************************** *
	 * ****************************************************************************************************** *
	 * Titelfeld mit Unterstrich
	 * ****************************************************************************************************** *
	 * ****************************************************************************************************** */
    editor.addButton('btnTopic', {
        text: 'Titelfeld',
        icon: false,
		tooltip: 'Titelfeld mit Unterstrich',
        onclick: function() {
            // Open window with a specific url
            editor.windowManager.open({
                title: 'Titelfeld mit Unterstrich',
				url: 'plugin_button_topic_field.php?<?php echo session_id(); ?>&lang=<?php echo $lang; ?>',
                width: 400,
                height: 400,
                buttons: [{
                    text: 'Close',
                    onclick: 'close'},{
                    text: 'Paste',
                    onclick: function(e) {
						var src = trim(svr.Sess("tinymce_plugin_src"));
						var idn = trim(svr.Sess("tinymce_plugin_id"));
						var txt = trim(svr.Sess("tinymce_plugin_text"));
						// *** //
						var con = '<div style = "border-bottom: 1px solid '+src+'; font-weight:'+idn+'; text-align:'+txt+';">Titelbereich</div><br />Text';
						// *** //
						tinyMCE.activeEditor.execCommand(
							'mceInsertContent', 
							false, con
						);
						// *** //
						editor.windowManager.close();
					}
                }]
            });
        }
    });

    /* ****************************************************************************************************** *
	 * ****************************************************************************************************** *
	 * Bild
	 * ****************************************************************************************************** *
	 * ****************************************************************************************************** */
    editor.addButton('btn5mImage', {
        text: 'Bild',
        icon: false,
		tooltip: 'Bild einbetten',
        onclick: function() {
            // Open window with a specific url
            editor.windowManager.open({
                title: 'Bild',
                url: 'plugin_uploadsifi.php?<?php echo session_id(); ?>',
                width: 860,
                height: 460,
                buttons: [{
                    text: 'Close',
                    onclick: 'close'},{
                    text: 'Paste',
                    onclick: function(e) {
						var url = trim(svr.Sess( "uplURL" ));
						var src = svr.Sess( "uplSOURCEFile" );
						var szw = svr.Sess( "uplWIDTH" );
						var szh = svr.Sess( "uplHEIGHT" );
						var sty = svr.Sess( "uplSTYLE" );
						// *** //
						if ( url == "" ) {
							tinyMCE.activeEditor.execCommand(
								'mceInsertContent', 
								false, 
								'<img border = "0" src = "' + src + '" style = "' + 'width: ' + szw + 'px; ' + 'height: ' + szh + 'px; ' + sty + 'px;" />'
							);
						} else {
							tinyMCE.activeEditor.execCommand(
								'mceInsertContent', 
								false, 
								'<img border = "0" src = "' + src + '" style = "' + 'width: ' + szw + 'px; ' + 'height: ' + szh + 'px; ' + sty + 'px;" onclick = "javascript:location.href = \'' + url + '\'" />'
							);
						}
						// *** //
						editor.windowManager.close();
					}
                }]
            });
        }
    });

});
