<?php

	$saving = $_GET['saving'];
	if ( $saving == "" ) { saving = $_POST['saving']; }

	if ( $saving == "chatstream" ) {

		$src = $_GET['s5mBackendSrc'];
		if ( $src == "" ) { $src = $_POST['s5mBackendSrc']; }

		if ( $src != "" ) {

			

		}

	}

?>